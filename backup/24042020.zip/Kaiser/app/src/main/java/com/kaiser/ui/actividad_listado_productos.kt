package com.kaiser.ui


import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.kaiser.R
import kotlinx.android.synthetic.main.activity_actividad_listado_productos.*
import kotlinx.android.synthetic.main.activity_n_usuario.*

class actividad_listado_productos : AppCompatActivity() {

    lateinit var aux : TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad_listado_productos)
        aux = findViewById(R.id.txtaux2)
        aux.text = intent.getStringExtra("opcion")
        Toast.makeText(this,"a", Toast.LENGTH_SHORT)
    }
}
