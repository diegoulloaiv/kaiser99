package com.kaiser.logica

import android.net.Uri

class usuario (var nombre : String, var usuario_id : String, var email : String,
    var telefono : String,var photourl : String, var direccion : String, var ciudad : String, var provincia: String)
