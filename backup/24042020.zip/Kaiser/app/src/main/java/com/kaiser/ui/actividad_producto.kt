package com.kaiser.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.room.Room
import androidx.room.RoomDatabase
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.kaiser.R
import com.kaiser.logica.AppDb
import com.kaiser.logica.CarroEntity
import com.kaiser.logica.usuario
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_actividad_producto.*
import kotlinx.android.synthetic.main.activity_n_usuario.*
import kotlinx.android.synthetic.main.recyclerview_item_row.view.*

class actividad_producto : AppCompatActivity() {

    lateinit var txtTitulo : TextView
    lateinit var id : String
    lateinit var imagen : ImageView
    lateinit var precio : TextView
    lateinit var BtnAgregar : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad_producto)
        txtTitulo = this.findViewById(R.id.TxtTitulo)
        id = intent.getStringExtra("id")
        txtTitulo.text = intent.getStringExtra("nombre")
        precio = this.findViewById(R.id.txt_precio)
        //CAMBiAR SEGUN EL USUARIO
        precio.text = intent.getStringExtra("precio1")

        imagen = this.findViewById(R.id.imageView)
        // Reference to an image file in Cloud Storage
        val storageReference = FirebaseStorage.getInstance().getReference("productos")
        // Download directly from StorageReference using Glide
        // (See MyAppGlideModule for Loader registration)
        Glide.with(this /* context */)
                .load(intent.getStringExtra("url"))
                .into(this.imagen)



        BtnAgregar = this.findViewById(R.id.BtnAgregar)
        BtnAgregar.setOnClickListener()
        {
            val thread = Thread {
                var carroEntity = CarroEntity()
                carroEntity.productoNombre = txtTitulo.text.toString()
                var aux: String = precio.text as String
                carroEntity.productoPrecio = aux.toDouble()
                val db = Room.databaseBuilder(applicationContext, AppDb::class.java, "CarroDB")
                        .fallbackToDestructiveMigration()
                        .build()
                db.carroDao().saveCarro(carroEntity)
            }
            thread.start()
        }

    }

}
