package com.kaiser.logica

import android.net.Uri

class proveedor (var id : String, var nombre: String, var imagen_url : String)